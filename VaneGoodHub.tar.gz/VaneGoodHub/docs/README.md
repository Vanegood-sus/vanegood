# VaneGood Hub v1.0

**Created by VaneGood**

## 🚀 Как запустить

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/VaneGood/Scripts/main/VaneGoodHub.lua", true))()
```

## 📋 Описание

VaneGood Hub - это современный мультиигровой хаб для Roblox с красно-черной темой. Хаб содержит скрипты для различных игр и имеет удобный интерфейс для выбора нужной игры.

## 🎮 Поддерживаемые игры

### ✅ Muscle Legends (ID: 3623096087)
- **Auto Win Brawls** - автоматическая победа в драках
- **Auto Join Brawls** - автоматическое присоединение к дракам  
- **Jungle Gym Training** - автоматические тренировки в джунглевом зале
  - Bench Press
  - Squat
  - Pull Ups
  - Boulder
- **Anti-AFK System** - защита от кика за неактивность

### 🔜 В разработке
- Pet Simulator X
- Blox Fruits
- Arsenal
- King Legacy

## 🛠️ Особенности

- **Современный дизайн** с красно-черной цветовой схемой
- **Модульная архитектура** - легко добавлять новые игры
- **Проверка игры** - скрипты загружаются только в правильных играх
- **Anti-AFK система** для всего хаба
- **Уведомления** о статусе загрузки
- **Безопасность** - все функции защищены от ошибок

## 📞 Контакты

- **Discord**: vanegood
- **Creator**: VaneGood

## 📝 Лицензия

Этот проект создан VaneGood для личного использования.

---

*VaneGood Hub v1.0 - Your Ultimate Roblox Experience*