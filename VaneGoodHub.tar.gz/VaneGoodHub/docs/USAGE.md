# Инструкции по использованию VaneGood Hub

## 📦 Как упаковать проект

### 1. Создание архива
```bash
cd roblox
tar -czf VaneGoodHub.tar.gz VaneGoodHub/
```

### 2. Загрузка на GitHub
1. Распакуй архив в свой GitHub репозиторий
2. Загрузи файлы в корень репозитория

### 3. Структура после загрузки на GitHub
```
your-repo/
├── VaneGoodHub.lua          # Главный файл хаба
├── games/
│   └── MuscleLegendsScript.lua
└── docs/
    ├── README.md
    └── USAGE.md
```

## 🚀 Запуск скрипта

### Главный хаб
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/main/VaneGoodHub.lua", true))()
```

### Только Muscle Legends (прямая загрузка)
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/main/games/MuscleLegendsScript.lua", true))()
```

## ⚙️ Настройка URL-ов

Замени в файле `VaneGoodHub.lua` строку:
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/VaneGood/Scripts/main/games/MuscleLegendsScript.lua", true))()
```

На свой URL:
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/main/games/MuscleLegendsScript.lua", true))()
```

## 📁 Структура проекта

```
VaneGoodHub/
├── VaneGoodHub.lua              # Главный хаб
├── games/                       # Папка со скриптами игр
│   └── MuscleLegendsScript.lua  # Скрипт для Muscle Legends
└── docs/                        # Документация
    ├── README.md                # Основная документация
    └── USAGE.md                 # Инструкции
```

## 🎮 Добавление новых игр

1. Создай новый файл в папке `games/`
2. Добавь проверку Game ID в хабе
3. Создай новую папку в Games Tab
4. Добавь кнопку загрузки скрипта

Пример для новой игры:
```lua
local newGameFolder = gamesTab:AddFolder("🎯 New Game")

newGameFolder:AddButton("🚀 Load New Game Script", function()
    if game.PlaceId == GAME_ID then
        loadstring(game:HttpGet("YOUR_URL_HERE", true))()
    else
        -- Error notification
    end
end)
```

## 🛠️ Настройка цветовой темы

Для изменения цветовой схемы, измени значение в `main_color`:
```lua
main_color = Color3.fromRGB(139, 0, 0), -- Dark Red
```

Популярные цвета:
- Красный: `Color3.fromRGB(139, 0, 0)`
- Синий: `Color3.fromRGB(0, 100, 200)`
- Зеленый: `Color3.fromRGB(0, 150, 0)`
- Фиолетовый: `Color3.fromRGB(128, 0, 128)`